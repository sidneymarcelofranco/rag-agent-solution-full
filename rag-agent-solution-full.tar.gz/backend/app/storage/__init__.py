"""
Módulo de armazenamento: MinIO e Google Drive.
"""

from app.storage.minio_client import MinIOClient

__all__ = ["MinIOClient"]
