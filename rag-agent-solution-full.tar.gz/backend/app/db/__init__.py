"""
Módulo de banco de dados: Conexão PostgreSQL e modelos.
"""

__all__ = []
