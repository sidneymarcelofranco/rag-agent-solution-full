"""
Aplicação RAG Agent Solution.
"""

__version__ = "1.0.0"
__author__ = "Manus AI"
