"""
Módulo de API: Rotas FastAPI e schemas.
"""

__all__ = []
